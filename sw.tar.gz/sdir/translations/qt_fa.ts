<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fa">
    <dependencies>
        <dependency catalog="qtbase_fa"/>
        <dependency catalog="qtscript_fa"/>
        <dependency catalog="qtquick1_fa"/>
        <dependency catalog="qtmultimedia_fa"/>
        <dependency catalog="qtxmlpatterns_fa"/>
    </dependencies>
</TS>

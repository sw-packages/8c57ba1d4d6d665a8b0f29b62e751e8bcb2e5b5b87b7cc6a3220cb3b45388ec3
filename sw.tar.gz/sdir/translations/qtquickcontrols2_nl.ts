<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL" sourcelanguage="nl_NL">
    <extra-po-header-language>nl</extra-po-header-language>
    <extra-po-header-language_team>Dutch &lt;kde-i18n-nl@kde.org&gt;</extra-po-header-language_team>
    <extra-po-header-last_translator>Freek de Kruijf &lt;freekdekruijf@kde.nl&gt;</extra-po-header-last_translator>
    <extra-po-header-plural_forms>nplurals=2; plural=(n != 1);</extra-po-header-plural_forms>
    <extra-po-header-po_revision_date>2018-04-19 13:43+0100</extra-po-header-po_revision_date>
    <extra-po-header-project_id_version></extra-po-header-project_id_version>
    <extra-po-header-x_generator>Lokalize 2.0</extra-po-header-x_generator>
    <extra-po-header_comment># Freek de Kruijf &lt;freekdekruijf@kde.nl&gt;, 2018.</extra-po-header_comment>
    <extra-po-headers>Project-Id-Version,PO-Revision-Date,Last-Translator,Language-Team,Language,MIME-Version,Content-Type,Content-Transfer-Encoding,X-Qt-Contexts,Plural-Forms,X-Generator</extra-po-headers>
<context>
    <name>QQuickPlatformDialog</name>
    <message>
        <source>Dialog is an abstract base class</source>
        <translation>Dialoog is een abstracte basisklasse</translation>
    </message>
    <message>
        <source>Cannot create an instance of StandardButton</source>
        <translation>Kan geen exemplaar van StandardButton aanmaken</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2ImagineStylePlugin</name>
    <message>
        <source>Imagine is an attached property</source>
        <translation>Imagine is een aangeplakte eigenschap</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2MaterialStylePlugin</name>
    <message>
        <source>Material is an attached property</source>
        <translation>Material is een aangeplakte eigenschap</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2UniversalStylePlugin</name>
    <message>
        <source>Universal is an attached property</source>
        <translation>Universal is een aangeplakte eigenschap</translation>
    </message>
</context>
</TS>
